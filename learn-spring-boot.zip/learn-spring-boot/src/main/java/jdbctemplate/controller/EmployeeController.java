package jdbctemplate.controller;

import jdbctemplate.dao.EmployeeDao;
import jdbctemplate.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//@RequestMapping("/api")
public class EmployeeController {
        @Autowired
        private EmployeeDao employeeDao;

        @PostMapping("/saveEmployee")
        public String saveEmployee(@RequestBody Employee employee){
            String msg = employeeDao.save(employee);
            return msg;
        }

        @GetMapping("/findAll")
        public List<Employee> getAllEmployee(){
            return employeeDao.findAll();
        }
//        @PutMapping("/updateRecord")






    }



