package com.springboot.di;

import org.springframework.stereotype.Component;

@Component
public class Student {
    private int id;
    private String name;

    public Student(){
        System.out.println(" in student Constructor");
    }

    public void display(){
        System.out.println(" in student display method");
    }

    public void show(){
        System.out.println(" i am in student show method");
    }
}
