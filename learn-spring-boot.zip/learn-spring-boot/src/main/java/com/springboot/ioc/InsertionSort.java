package com.springboot.ioc;

public class InsertionSort implements SortingTechniques{
    @Override
    public void sort() {
        System.out.println(" In insertion sort method");
    }

    @Override
    public void display() {
        System.out.println(" in insertion display method");

    }
}
