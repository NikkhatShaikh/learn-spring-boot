package com.springboot.ioc;

public class BubbleSort implements SortingTechniques{

    @Override
    public void sort() {
        System.out.println(" In bubble sort method");
    }

    @Override
    public void display() {

        System.out.println(" in bubble sort display method ");
    }
}
