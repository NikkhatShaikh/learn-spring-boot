package com.springboot.ioc;

public interface SortingTechniques {
    void sort();
    void display();
}
